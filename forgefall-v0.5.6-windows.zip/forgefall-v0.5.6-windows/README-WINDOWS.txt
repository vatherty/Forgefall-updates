FORGEFALL v0.5.6 — Windows (64-bit)
===================================

Same game as the Android v0.5.6 build: voxel MW2-style FPS with
portals, grapple, wall-running, and the AI Forge console.

RUN IT
------
  1. Unzip this file anywhere.
  2. Double-click forgefall.exe (or run it from a terminal).

Keep forgefall.pck in the same folder as forgefall.exe — the game
will not start without it. No install, no admin rights needed.
Window is 1280x720 by default and resizable. Requires Windows 10/11
64-bit with Vulkan/OpenGL drivers.

MOUSE CAPTURE
-------------
  - In gameplay the mouse is CAPTURED: it hides and steers the camera.
  - In menus (main menu, pause, Forge console) the mouse is VISIBLE
    and free, so you can click buttons normally.
  - Press Esc (or P) to pause — this releases the mouse. Click
    "Resume" (or press Esc again) to re-capture it and keep playing.
  - If the mouse ever feels stuck, press Esc to pause, then resume.

CONTROLS — KEYBOARD + MOUSE
---------------------------
  WASD / Arrows .... move            Mouse ............ look
  Left mouse ....... fire            Right mouse ...... aim down sights
  Space ............ jump            Shift ............ sprint
  C or Ctrl ........ crouch / slide  R ................ reload
  G ................ grapple         Q / E ............ blue / orange portal
  T or / ........... Forge console   F ................ interact
  1 / 2 / 3 ........ weapon slots    4 / 5 / 6 ........ killstreaks
  Esc / P .......... pause

CONTROLS — GAMEPAD (Xbox-style, native)
----------------------------------------
  Left stick ......... move            Right stick ...... look
  Right trigger (RT) . fire             Left trigger (LT)  aim down sights
  A .................. jump             B ................ crouch / slide
  X .................. reload           Y ................ interact
  Left stick click ... sprint           LB ............... grapple
  RB ................. Forge console    Start ............ pause
  D-pad Up/Right/Down  weapon slots 1/2/3

MULTIPLAYER — TEAM DEATHMATCH (LAN / direct IP)
----------------------------------------------
  Main menu > MULTIPLAYER. One player hosts (pick map, then
  Host); others join from the LAN browser or by direct IP:port
  (default port 7777). Two teams, first to 25 kills wins.
  No central server, no account — everyone must be on the
  same local network (or otherwise able to reach the host's
  IP:port). If the host leaves, the match ends. Co-op waves
  are not in this release.

PORTALS — SEE-THROUGH + PUZZLE CHAMBERS
-----------------------------------------
  Portal discs now show a LIVE view through their paired portal
  (small render target; quality scales down on low settings).
  Teleporting conserves momentum: fall in fast, fly out fast.
  The crosshair tints by placement verdict (white = placeable,
  red = surface rejects, amber = out of range) and the two pips
  under it show which portal discs are live.
  Main menu > PUZZLE CHAMBERS: 4 hand-built chambers —
  First Steps (portal basics), Heavy Lifting (block + plate +
  door), Fling (momentum), The Gauntlet (all three combined).
  White panels are portal-able; dark surfaces are not.
  Completion is saved and survives restarts.



LLM-AUTHORED HOOK SCRIPTS — v0.5.6
----------------------------------
  - When the effect table doesn't cover your request, the LLM may
    now author a GDScript hook (extends ModHook) for the mod —
    data hooks from the effect table are still preferred whenever
    they can express it. Code hooks are the fallback for genuinely
    new behaviour, not the default.
  - Hook scripts may call ONLY the ModAPI allowlist (ModAPI
    HOOK_ALLOWED_*) plus listed safe builtins — anything else is
    rejected with the violation named. A hook that errors at load
    or run disables its mod visibly, never crashes.
  - Step/time budget: at most 200 ModAPI calls and 100 ms per hook
    run, 250 ms per dispatch. Exceeding it aborts the dispatch and
    disables the mod visibly.
  - Approval shows the hook script source and labels it
    LLM-authored. TEST IN SANDBOX runs code hooks against the
    dummy and reports what they did.
  - Honest limit: a tight loop with no API calls cannot be
    preempted (GDScript has no preemptive timeout) — it hangs the
    frame. `while` loops are rejected at validation; use bounded
    `for` loops.


STATUS EFFECTS FOR INVENTED HOOKS — v0.5.5
------------------------------------------
  - Mods can now apply real STATUS EFFECTS: slow (speed x factor
    for N seconds), freeze (speed 0), burn (damage per second),
    and knockback (impulse away from the hit). They work on
    on_hit / on_kill (the hit target) or on_damage_taken (you).
  - The Bubble Blaster gap is closed: before this release the
    effect catalog had no slow, so a "slows enemies" blaster
    could only express slowing as smoke + a message. Now slow
    is a first-class effect kind.
  - The sandbox REPORTS status effects: e.g. "SLOWED: dummy
    speed 4.0 -> 2.0 m/s for 3.0s." / "BURNING: 10 damage/s
    for 5.0s." / "KNOCKBACK: force 12." Approval screens list
    effects per hook, so you see them before installing.
  - CONTRIBUTING.md (in the repo) documents how to add a new
    effect kind in six steps.


CHAT IN CREATE-A-MOD — v0.5.5
-------------------------------
  - Create-a-Mod (main menu) now has FOUR tabs: CREATE / CHAT /
    MODS / IMPORT-EXPORT.
  - The CHAT tab is a free-form conversation with the model:
    message bubbles, suggested prompts (including "What can you
    do?"), CLEAR / NEW CHAT, and CREATE FROM CHAT.
  - Chat and Create share ONE session (last 20 messages, saved
    across restarts), so you can brainstorm in chat and then
    turn the conversation into a mod — it goes through the same
    generation → validation → approval → Install flow.
  - Chat answers are grounded in the true capability list, and
    the greeting lists what the creator can actually do.
  - Same DeepSeek key as Forge. No key or an LLM failure shows
    a visible error — there is no silent offline fallback.
    Chat never installs anything on its own.

FORGE MAKE + INVENTED HOOKS — v0.5.3
------------------------------------
  - Forge MAKE: one-box creation in the Forge menu. Type one
    prompt, get a one-shot creation that lives for THIS SESSION
    ONLY — never saved, gone on quit. For quick experiments
    without cluttering your mod list.
  - Create-a-Mod can now INVENT HOOKS: when no existing hook
    expresses what the mod needs, the generator may create a
    new hook/script for it. Forbidden APIs are still rejected,
    and the approval screen lists invented hooks explicitly.
  - Custom projectiles fire in the REAL GAME now, not just the
    sandbox: a Long Laser Pistol fires a beam; a watermelon LMG
    fires watermelons that explode on impact.
  - Known limits: script-mod candidates can't run in-session
    via MAKE (it refuses and points you to Create-a-Mod); MAKE
    skips Forge undo / MP-sync / history; on_damage_taken
    damage_mult above 1 is ignored; turret damage hooks
    aren't wired yet.


CREATE-A-MOD FIXES — v0.5.2
----------------------------
  - Sandbox test now flies the candidate mod's PROJECTILE (what
    the mod fires), not a generic launcher. The weapon visual
    still shows at the shooter, static, so you can see both.
  - Mods lists fixed in BOTH the Create-a-Mod menu and the Forge
    menu: the list was rendering at 0px tall (invisible) because
    of a nested-scroll layout bug. Installed mods show up
    immediately after install now.


FORGE BATCH — v0.5.2 (BUILDING IS FREE FOR NOW)
-------------------------------------------------
  - Forge budget is OFF: building costs nothing right now
    (costs are still computed and shown; the budget may come
    back later). The 12-structure cap stays (performance).
  - Ghost preview: structure prompts show a translucent ghost
    first — INTERACT places it, ESC cancels. After placing,
    the Forge menu's PLACED STRUCTURES list lets you MOVE /
    ROTATE / REPAIR / DELETE.
  - Destructible structures: enemies can damage Forge
    structures; repair with the interact key nearby (or the
    REPAIR button). Structures break at 0 HP.
  - Forge in multiplayer: placed structures sync to every peer.
  - Real per-weapon Forge costs (shown in the preview).
  - New Build presets: stairs, ramps, walls, jump pads
    (launch you), cover pieces, sniper nests.
  - Shareable build codes: COPY LAST CODE in Forge, send the
    code to a friend, paste it in BUILD FROM CODE to rebuild.
    History is searchable.
  - CREATE A MOD (main menu): its own menu with CREATE / CHAT / MODS /
    IMPORT-EXPORT tabs. The CREATE form takes categories
    (multi-choice), name, visual description, and logic —
    e.g. "an LMG that shoots watermelons. The watermelons
    explode on impact." The pipeline generates the mod +
    a procedural voxel model (cached, reused for the same
    description), then shows summary + full payload for your
    approval (Install / Discard / Regenerate). TEST IN SANDBOX
    tries it in a test room before it touches the real game.
    IMPORT/EXPORT is a placeholder for a later update.
  - Voice forging v2 (Android): the MIC prompt now shows
    what was heard and waits for CONFIRM / RETRY / CANCEL
    before building anything. Push-to-talk: hold MIC, release
    to send — nothing builds until you confirm.

PROGRESSION — XP, LEVELS, UNLOCKS, LOADOUTS, STATS
---------------------------------------------------
  Earn XP from kills, Domination captures/holds, match wins,
  wave survival, and puzzle-chamber completions. Level up to
  unlock titles, emblems, voxel camo recolors, and extra
  custom loadout slots. Nothing playable is locked — unlocks
  are additions, not removals.
  Main menu > LOADOUTS: build and pick persistent custom
  loadouts (weapon + Forge preset) — the same loadouts the
  Forge tab uses. Main menu > STATS: lifetime kills, deaths,
  K/D, accuracy, wins/losses, best Endless wave/score, and
  per-weapon / per-mode stats. Progress and stats persist
  across updates.

NOTES
-----
- Voice forging (MIC) is Android-only; on Windows the Forge
  console is typed. A DeepSeek key can be entered in-game in
  the Forge menu for live AI builds.
- User mods live in:
    %APPDATA%\Godot\app_userdata\FORGEFALL\mods\
  (paste that path into File Explorer's address bar). JSON blocks
  and GDScript ModBlock scripts work the same as on Android.
  Enable/disable mods in the in-game Mods tab.
- In-game updater: the game checks for updates on launch
  (Options > CHECK FOR UPDATES for a manual check). When one is
  ready, confirm Download, then INSTALL NOW — a helper script
  waits for the game to quit, copies the new files over the
  install folder, and relaunches. If the helper ever fails, the
  dialog shows the downloaded ZIP path — unzip it over your
  install folder and relaunch.
- Free, no account or sign-in needed.
