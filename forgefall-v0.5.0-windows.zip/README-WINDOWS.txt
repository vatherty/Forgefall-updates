FORGEFALL v0.5.0 — Windows (64-bit)
===================================

Same game as the Android v0.5.0 build: voxel MW2-style FPS with
portals, grapple, wall-running, and the AI Forge console.

Renumbered from 0.9.5 — same game, same content; the old
numbering implied it was further along than it is.

RUN IT
------
  1. Unzip this file anywhere.
  2. Double-click forgefall.exe (or run it from a terminal).

Keep forgefall.pck in the same folder as forgefall.exe — the game
will not start without it. No install, no admin rights needed.
Window is 1280x720 by default and resizable. Requires Windows 10/11
64-bit with Vulkan/OpenGL drivers.

MOUSE CAPTURE
-------------
  - In gameplay the mouse is CAPTURED: it hides and steers the camera.
  - In menus (main menu, pause, Forge console) the mouse is VISIBLE
    and free, so you can click buttons normally.
  - Press Esc (or P) to pause — this releases the mouse. Click
    "Resume" (or press Esc again) to re-capture it and keep playing.
  - If the mouse ever feels stuck, press Esc to pause, then resume.

CONTROLS — KEYBOARD + MOUSE
---------------------------
  WASD / Arrows .... move            Mouse ............ look
  Left mouse ....... fire            Right mouse ...... aim down sights
  Space ............ jump            Shift ............ sprint
  C or Ctrl ........ crouch / slide  R ................ reload
  G ................ grapple         Q / E ............ blue / orange portal
  T or / ........... Forge console   F ................ interact
  1 / 2 / 3 ........ weapon slots    4 / 5 / 6 ........ killstreaks
  Esc / P .......... pause

CONTROLS — GAMEPAD (Xbox-style, native)
----------------------------------------
  Left stick ......... move            Right stick ...... look
  Right trigger (RT) . fire             Left trigger (LT)  aim down sights
  A .................. jump             B ................ crouch / slide
  X .................. reload           Y ................ interact
  Left stick click ... sprint           LB ............... grapple
  RB ................. Forge console    Start ............ pause
  D-pad Up/Right/Down  weapon slots 1/2/3

MULTIPLAYER — TEAM DEATHMATCH (LAN / direct IP)
----------------------------------------------
  Main menu > MULTIPLAYER. One player hosts (pick map, then
  Host); others join from the LAN browser or by direct IP:port
  (default port 7777). Two teams, first to 25 kills wins.
  No central server, no account — everyone must be on the
  same local network (or otherwise able to reach the host's
  IP:port). If the host leaves, the match ends. Co-op waves
  are not in this release.

PORTALS — SEE-THROUGH + PUZZLE CHAMBERS
-----------------------------------------
  Portal discs now show a LIVE view through their paired portal
  (small render target; quality scales down on low settings).
  Teleporting conserves momentum: fall in fast, fly out fast.
  The crosshair tints by placement verdict (white = placeable,
  red = surface rejects, amber = out of range) and the two pips
  under it show which portal discs are live.
  Main menu > PUZZLE CHAMBERS: 4 hand-built chambers —
  First Steps (portal basics), Heavy Lifting (block + plate +
  door), Fling (momentum), The Gauntlet (all three combined).
  White panels are portal-able; dark surfaces are not.
  Completion is saved and survives restarts.


PROGRESSION — XP, LEVELS, UNLOCKS, LOADOUTS, STATS
---------------------------------------------------
  Earn XP from kills, Domination captures/holds, match wins,
  wave survival, and puzzle-chamber completions. Level up to
  unlock titles, emblems, voxel camo recolors, and extra
  custom loadout slots. Nothing playable is locked — unlocks
  are additions, not removals.
  Main menu > LOADOUTS: build and pick persistent custom
  loadouts (weapon + Forge preset) — the same loadouts the
  Forge tab uses. Main menu > STATS: lifetime kills, deaths,
  K/D, accuracy, wins/losses, best Endless wave/score, and
  per-weapon / per-mode stats. Progress and stats persist
  across updates.

NOTES
-----
- Voice forging (MIC) is Android-only; on Windows the Forge
  console is typed. A DeepSeek key can be entered in-game in
  the Forge menu for live AI builds.
- User mods live in:
    %APPDATA%\Godot\app_userdata\FORGEFALL\mods\
  (paste that path into File Explorer's address bar). JSON blocks
  and GDScript ModBlock scripts work the same as on Android.
  Enable/disable mods in the in-game Mods tab.
- In-game updater: the game checks for updates on launch
  (Options > CHECK FOR UPDATES for a manual check). When one is
  ready, confirm Download, then INSTALL NOW — a helper script
  waits for the game to quit, copies the new files over the
  install folder, and relaunches. If the helper ever fails, the
  dialog shows the downloaded ZIP path — unzip it over your
  install folder and relaunch.
- Free, no account or sign-in needed.
