FORGEFALL v0.8.0 — Linux (x86_64) / Steam Deck
================================================

Same game as the Android v0.8.0 build: voxel MW2-style FPS with
portals, grapple, wall-running, and the AI Forge console.

RUN IT
------
  1. Unzip this file anywhere.
  2. chmod +x forgefall.x86_64
  3. ./forgefall.x86_64

Keep forgefall.pck in the same folder as the binary — the game
will not start without it. No install, no dependencies beyond a
64-bit Linux with Vulkan/OpenGL drivers. Window is 1280x720 by
default and resizable; on the Deck's 1280x800 screen it fills
the display with small letterbox bars.

STEAM DECK (Desktop Mode)
-------------------------
  1. In Desktop Mode, open Steam > Games > Add a Non-Steam Game
     to My Library > Browse, and pick forgefall.x86_64.
  2. In the game's Steam Properties, set the Launch Options to
     the full path if Steam doesn't resolve it, e.g.:
       "/home/deck/Games/forgefall-v0.8.0-linux/forgefall.x86_64"
  3. Launch from Game Mode or Desktop Mode.

CONTROLS — KEYBOARD + MOUSE (no native gamepad support)
--------------------------------------------------------
This build has NO native gamepad bindings, so on the Deck use
Steam Input with a Keyboard + Mouse template:
  Left stick/trackpad -> WASD (move)     Right stick/trackpad -> Mouse (look)
  Right trigger       -> Left mouse (fire)  Left trigger        -> Right mouse (ADS)
  A -> Space (jump)     B -> C or Ctrl (crouch / slide)
  X -> R (reload)       Y -> G (grapple)    Back/View -> T (Forge console)
  D-pad / face buttons -> 1/2/3 weapons, 4/5/6 killstreaks, F interact

Full keyboard + mouse layout:
  WASD / Arrows .... move            Mouse ............ look
  Left mouse ....... fire            Right mouse ...... aim down sights
  Space ............ jump            Shift ............ sprint
  C or Ctrl ........ crouch / slide  R ................ reload
  G ................ grapple         Q / E ............ blue / orange portal
  T or / ........... Forge console   F ................ interact
  1 / 2 / 3 ........ weapon slots    4 / 5 / 6 ........ killstreaks
  Esc / P .......... pause

Note: the Deck's touchscreen may make the touch buttons appear
(the game shows them whenever a touchscreen is detected). The
Steam Input keyboard+mouse layout above is the recommended way
to play; the touch buttons are harmless if they show.

NOTES
-----
- Voice forging (MIC) is Android-only; on Linux the Forge
  console is typed. A DeepSeek key can be entered in-game in
  the Forge menu for live AI builds.
- User mods live in ~/.local/share/godot/app_userdata/FORGEFALL/mods/
  (the standard Godot user:// folder on Linux). JSON blocks and
  GDScript ModBlock scripts work the same as on Android.
- The in-game updater is Android-only: it opens the download
  page in your browser instead of installing. Grab new Linux
  builds from the download page.
- Free, no account or sign-in needed.
