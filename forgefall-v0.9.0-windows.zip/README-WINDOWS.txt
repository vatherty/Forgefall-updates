FORGEFALL v0.9.0 — Windows (64-bit)
=====================================

Same game as the Android v0.9.0 build: voxel MW2-style FPS with
portals, grapple, wall-running, and the AI Forge console.

RUN IT
------
  1. Unzip this file anywhere.
  2. Double-click forgefall.exe (or run it from a terminal).

Keep forgefall.pck in the same folder as forgefall.exe — the game
will not start without it. No install, no admin rights needed.
Window is 1280x720 by default and resizable. Requires Windows 10/11
64-bit with Vulkan/OpenGL drivers.

MOUSE CAPTURE
-------------
  - In gameplay the mouse is CAPTURED: it hides and steers the camera.
  - In menus (main menu, pause, Forge console) the mouse is VISIBLE
    and free, so you can click buttons normally.
  - Press Esc (or P) to pause — this releases the mouse. Click
    "Resume" (or press Esc again) to re-capture it and keep playing.
  - If the mouse ever feels stuck, press Esc to pause, then resume.

CONTROLS — KEYBOARD + MOUSE
---------------------------
  WASD / Arrows .... move            Mouse ............ look
  Left mouse ....... fire            Right mouse ...... aim down sights
  Space ............ jump            Shift ............ sprint
  C or Ctrl ........ crouch / slide  R ................ reload
  G ................ grapple         Q / E ............ blue / orange portal
  T or / ........... Forge console   F ................ interact
  1 / 2 / 3 ........ weapon slots    4 / 5 / 6 ........ killstreaks
  Esc / P .......... pause

CONTROLS — GAMEPAD (Xbox-style, native)
----------------------------------------
  Left stick ......... move            Right stick ...... look
  Right trigger (RT) . fire             Left trigger (LT)  aim down sights
  A .................. jump             B ................ crouch / slide
  X .................. reload           Y ................ interact
  Left stick click ... sprint           LB ............... grapple
  RB ................. Forge console    Start ............ pause
  D-pad Up/Right/Down  weapon slots 1/2/3

NOTES
-----
- Voice forging (MIC) is Android-only; on Windows the Forge
  console is typed. A DeepSeek key can be entered in-game in
  the Forge menu for live AI builds.
- User mods live in:
    %APPDATA%\Godot\app_userdata\FORGEFALL\mods\
  (paste that path into File Explorer's address bar). JSON blocks
  and GDScript ModBlock scripts work the same as on Android.
  Enable/disable mods in the in-game Mods tab.
- The in-game updater is Android-only: on Windows it opens the
  download page in your browser instead of installing. Grab new
  Windows builds from the download page.
- Free, no account or sign-in needed.
