#!/bin/sh
printf '\033c\033]0;%s\a' FORGEFALL
base_path="$(dirname "$(realpath "$0")")"
"$base_path/forgefall.x86_64" "$@"
