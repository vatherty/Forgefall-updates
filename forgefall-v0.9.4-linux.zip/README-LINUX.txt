FORGEFALL v0.9.4 — Linux (x86_64) / Steam Deck
================================================

Same game as the Android v0.9.4 build: voxel MW2-style FPS with
portals, grapple, wall-running, and the AI Forge console.

RUN IT
------
  1. Unzip this file anywhere.
  2. chmod +x forgefall.x86_64
  3. ./forgefall.x86_64

Keep forgefall.pck in the same folder as the binary — the game
will not start without it. No install, no dependencies beyond a
64-bit Linux with Vulkan/OpenGL drivers. Window is 1280x720 by
default and resizable; on the Deck's 1280x800 screen it fills
the display with small letterbox bars.

STEAM DECK (Desktop Mode)
-------------------------
  1. In Desktop Mode, open Steam > Games > Add a Non-Steam Game
     to My Library > Browse, and pick forgefall.x86_64.
  2. In the game's Steam Properties, set the Launch Options to
     the full path if Steam doesn't resolve it, e.g.:
       "/home/deck/Games/forgefall-v0.9.4-linux/forgefall.x86_64"
  3. Launch from Game Mode or Desktop Mode. Leave the
     controller layout on Steam's default "Gamepad" template —
     the game reads the pad natively, no Steam Input remap
     needed.

CONTROLS — GAMEPAD (Xbox / Steam Deck, native)
----------------------------------------------
This build has native gamepad support.
  Left stick ......... move            Right stick ...... look
  Right trigger (RT) . fire             Left trigger (LT)  aim down sights
  A .................. jump             B ................ crouch / slide
  X .................. reload           Y ................ interact
  Left stick click ... sprint           LB ............... grapple
  RB ................. Forge console    Start ............ pause
  D-pad Up/Right/Down  weapon slots 1/2/3

Keyboard-only: Q / E (blue / orange portal), 4 / 5 / 6
(killstreaks). T or / also opens the Forge console.

Full keyboard + mouse layout:
  WASD / Arrows .... move            Mouse ............ look
  Left mouse ....... fire            Right mouse ...... aim down sights
  Space ............ jump            Shift ............ sprint
  C or Ctrl ........ crouch / slide  R ................ reload
  G ................ grapple         Q / E ............ blue / orange portal
  T or / ........... Forge console   F ................ interact
  1 / 2 / 3 ........ weapon slots    4 / 5 / 6 ........ killstreaks
  Esc / P .......... pause

Note: the Deck's touchscreen may make the touch buttons appear
(the game shows them whenever a touchscreen is detected).
The native gamepad layout above is the recommended way
to play; the touch buttons are harmless if they show.

MULTIPLAYER — TEAM DEATHMATCH (LAN / direct IP)
----------------------------------------------
  Main menu > MULTIPLAYER. One player hosts (pick map, then
  Host); others join from the LAN browser or by direct IP:port
  (default port 7777). Two teams, first to 25 kills wins.
  No central server, no account — everyone must be on the
  same local network (or otherwise able to reach the host's
  IP:port). If the host leaves, the match ends. Co-op waves
  are not in this release.

PORTALS — SEE-THROUGH + PUZZLE CHAMBERS
-----------------------------------------
  Portal discs now show a LIVE view through their paired portal
  (small render target; quality scales down on low settings).
  Teleporting conserves momentum: fall in fast, fly out fast.
  The crosshair tints by placement verdict (white = placeable,
  red = surface rejects, amber = out of range) and the two pips
  under it show which portal discs are live.
  Main menu > PUZZLE CHAMBERS: 4 hand-built chambers —
  First Steps (portal basics), Heavy Lifting (block + plate +
  door), Fling (momentum), The Gauntlet (all three combined).
  White panels are portal-able; dark surfaces are not.
  Completion is saved and survives restarts.

NOTES
-----
- Voice forging (MIC) is Android-only; on Linux the Forge
  console is typed. A DeepSeek key can be entered in-game in
  the Forge menu for live AI builds.
- User mods live in ~/.local/share/godot/app_userdata/FORGEFALL/mods/
  (the standard Godot user:// folder on Linux). JSON blocks and
  GDScript ModBlock scripts work the same as on Android.
- In-game updater: the game checks for updates on launch
  (Options > CHECK FOR UPDATES for a manual check). When one is
  ready, confirm Download, then INSTALL NOW — a helper script
  waits for the game to quit, copies the new files over the
  install folder, and relaunches. If the helper ever fails, the
  dialog shows the downloaded ZIP path — unzip it over your
  install folder and relaunch.
- Free, no account or sign-in needed.
